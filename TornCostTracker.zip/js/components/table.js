/**
 * Reusable table component (v1.1)
 */
let sortKey=null;
let descending=true;
export function createTable(columns,data){
 const table=document.createElement("table");
 table.className="tct-table";
 const thead=document.createElement("thead");
 const hr=document.createElement("tr");
 if(!sortKey){
   const def=columns.find(c=>c.defaultSort)||columns[0];
   sortKey=def.key; descending=true;
 }
 const sorted=[...data].sort((a,b)=>{
   const col=columns.find(c=>c.key===sortKey);
   let av=a[sortKey],bv=b[sortKey];
   let cmp=(col?.type==="number")?(Number(av)-Number(bv)):String(av).localeCompare(String(bv));
   return descending?-cmp:cmp;
 });
 columns.forEach(c=>{
   const th=document.createElement("th");
   const arrow=sortKey===c.key?(descending?" ▼":" ▲"):"";
   th.textContent=c.label+arrow;
   th.style.cursor="pointer";
   th.onclick=()=>{
      if(sortKey===c.key){descending=!descending;}else{sortKey=c.key;descending=true;}
      table.replaceWith(createTable(columns,data));
   };
   hr.appendChild(th);
 });
 thead.appendChild(hr); table.appendChild(thead);
 const tb=document.createElement("tbody");
 sorted.forEach(r=>{
   const tr=document.createElement("tr");
   columns.forEach(c=>{
     const td=document.createElement("td");
     td.textContent=r[c.key]??"";
     if(c.type==="number") td.style.textAlign="right";
     tr.appendChild(td);
   });
   tb.appendChild(tr);
 });
 table.appendChild(tb);
 return table;
}
