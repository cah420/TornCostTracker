# v0.5.2
Item Store added.

## v0.5.3.1
- Improved sortable table UX.
